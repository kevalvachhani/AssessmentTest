import requests
from bs4 import BeautifulSoup
import nltk
from nltk.tag import CRFTagger

# Download the pre-trained CRF tagger
nltk.download('maxent_ne_chunker')
nltk.download('words')

# Load the pre-trained CRF tagger
ct = CRFTagger()
ct.set_model_file('crf.model')

# Define the URL to extract entities from
url = "https://en.wikipedia.org/wiki/Sachin_Tendulkar"

# Fetch the HTML content from the URL
html = requests.get(url).content

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(html, 'html.parser')

# Extract the text content from the HTML
text = soup.get_text()

# Tokenize the text into words
words = nltk.word_tokenize(text)

# Tag the words with their corresponding entities using the pre-trained tagger
tags = ct.tag(words)

# Extract the entities from the tagged words
entities = nltk.chunk.ne_chunk(tags)

# Print the extracted entities
for entity in entities:
    if hasattr(entity, 'label'):
        print(entity.label(), ' '.join(c[0] for c in entity.leaves()))
