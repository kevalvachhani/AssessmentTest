import pandas as pd
from pandas_profiling import ProfileReport

# Load the resumes data into a pandas dataframe
df  = pd.read_csv('resumes.csv')
# df  = pd.read_csv('housing.csv')
print(df)

#  Generate report in html
profile = ProfileReport(df)

# for resumes dataset
profile.to_file(output_file="resumes.html")

#  for housing dataset
# profile.to_file(output_file="housing.html")